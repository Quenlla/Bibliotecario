﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Aplicacion_Novelas
{
    public class Novela
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Resumen { get; set; }
        public List<Capitulo> Capitulos { get; set; }
        public List<Personaje> Personajes { get; set; }
    
          /// <summary>
          /// Constructor de la clase
          /// </summary>
          /// <param name="Titulo">Titulo de la novela</param>
          /// <param name="Autor">Autor de la novela</param>
          /// <param name="Resumen">Resumen de la novela</param>
        public Novela(string Titulo, string Autor, string Resumen)
        {
            this.Titulo = Titulo;
            this.Autor = Autor;
            this.Resumen = Resumen;
            Personajes = new List<Personaje>();
            Capitulos = new List<Capitulo>();
        }

      
    }
}
