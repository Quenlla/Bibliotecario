﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Aplicacion_Novelas.Forms.Edit;
using Aplicacion_Novelas.Forms.Showall;

namespace Aplicacion_Novelas
{
    public partial class FNovelaXeral : Form
    {
        public List<Novela> Novelas = new List<Novela>();
        /// <summary>
        /// Constructor, carga un tooltip para indicar como funciona el boton buscar, asi como inicia el metodo cargarDatos para recuperar la informacion
        /// en caso de que exista previamente, inicia del mismo modo los datagridviews y el listview de las novelas.
        /// </summary>
        public FNovelaXeral()
        {
            try { 
            CargarDatos(this.Novelas);
            }
            catch
            {
            }
            InitializeComponent();
            ToolTip tp = new ToolTip();
            tp.ShowAlways = true;
            tp.AutoPopDelay = 2000;
            tp.InitialDelay = 500;
            tp.ReshowDelay = 500;
            tp.SetToolTip(this.btnBuscar, "Deje en blanco el texto para mostrar todas las novelas");
            lvNovelas.Columns.Add("Titulo");
            lvNovelas.FullRowSelect = true;
            lvNovelas.Alignment = ListViewAlignment.SnapToGrid;

            dgvCaracteristicas.Columns.Add(new DataGridViewColumn() { HeaderText = "Capitulos", CellTemplate = new DataGridViewTextBoxCell() }); 
            dgvCaracteristicas.Columns.Add(new DataGridViewColumn() { HeaderText = "Personajes", CellTemplate = new DataGridViewTextBoxCell() });
            foreach (Novela n in Novelas)
            {
                lvNovelas.Items.Add(n.Titulo,n.Titulo);
            }
        }
        /// <summary>
        /// Crea una nueva novela llamando al form correspondiente y actualiza el listview de las novelas.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNueva_Click(object sender, EventArgs e)
        {
            new FNuevaNovela(Novelas).ShowDialog();
            lvNovelas.Clear();
            foreach (Novela n in Novelas)
            {
                lvNovelas.Items.Add(n.Titulo);
            }
            lvNovelas.Update();
        }
        /// <summary>
        /// actualiza los datos a mostrar en el datagridview con las características de la novela
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lvNovelas_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            try
            {
                Novela n = Novelas.Where(n => n.Titulo == lvNovelas.SelectedItems[0].Text).First();
                dgvCaracteristicas.Rows.Clear();
                dgvCaracteristicas.Rows.Add(n.Capitulos.Count.ToString(), n.Personajes.Count.ToString());
            }
            catch (Exception ex)
            {
            }
         }
        /// <summary>
        /// Muestra el formulario de la novela seleccionada en el listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lvNovelas_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try { 
            Novela n = Novelas.Where(n=>n.Titulo== lvNovelas.SelectedItems[0].Text).First();
            new FNovelaParticular(n).ShowDialog();
            }catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        /// <summary>
        /// Limpia de elementos el listview de novelas y a continuacion busca las novelas con un titulo similar al texto indicado en el textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            lvNovelas.Clear();
            if (tBbuscar.Text == "")
            {
                foreach (Novela n in Novelas)
                {
                    lvNovelas.Items.Add(n.Titulo);
                }
            }
            else
            {
                foreach (Novela n in Novelas.Where(t=>t.Titulo.Contains(tBbuscar.Text)))
                {
                    lvNovelas.Items.Add(n.Titulo);
                }
            }
            lvNovelas.Update();
        }
        /// <summary>
        /// Lanza el formulario de edicion correspondiente para la novela seleccionada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditar_Click(object sender, EventArgs e)
        {
            try { 
            Novela n = Novelas.Where(n => n.Titulo == lvNovelas.SelectedItems[0].Text).First();
            new FEditNovela(n).ShowDialog();
            }catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        /// <summary>
        /// Lanza el formulario particular de vista para la novela seleccionada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVer_Click(object sender, EventArgs e)
        {
            try { 
            Novela n = Novelas.Where(n => n.Titulo == lvNovelas.SelectedItems[0].Text).First();
            new FNovelaParticular(n).ShowDialog();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                    }
        }


        /// <summary>
        /// Elimina la novela seleccionada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                Novela nr = Novelas.Where(n => n.Titulo == lvNovelas.SelectedItems[0].Text).First();
                Novelas.Remove(nr);
                lvNovelas.Clear();
                foreach (Novela n in Novelas)
                {
                    lvNovelas.Items.Add(n.Titulo);
                }
                lvNovelas.Update();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        /// <summary>
        /// Lanza el TreeView con las novelas registradas en el sistema
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRes_Click(object sender, EventArgs e)
        {
             new FTreeView(Novelas).ShowDialog();
            lvNovelas.Update();

        }
        /// <summary>
        /// lee los datos guardados en el documento Novelas.doc, recorriendo los nodos dentro del mismo y creando los objetos correspondientes
        /// </summary>
        /// <param name="Novelas"></param>
        private void CargarDatos(List<Novela> Novelas)
        {
            XmlDocument docXml = new XmlDocument();
            docXml.Load( "Novelas.dat" );
            foreach(XmlNode nodo in docXml.DocumentElement.ChildNodes)
            {
                Novela n;
                try
                {
                     n = new Novela(nodo.Attributes[0].InnerText, nodo.Attributes[1].InnerText, nodo.Attributes[2].InnerText);
                    foreach (XmlNode nod in nodo.ChildNodes)
                    {
                        RecorrerNodos(nod, n);
                    }
                }
                catch(Exception ex)
                {

                     n = new Novela("as", "as", "as");
                    
                }
                Novelas.Add(n);
            }


        }
        /// <summary>
        /// metodo auxiliar a CargarDatos que recorre los nodos de capitulos y de personajes y llama al metodo recorrerPasajes para cada capitulo
        /// </summary>
        /// <param name="x"></param>
        /// <param name="nov"></param>
        private void RecorrerNodos(XmlNode x, Novela nov)
        {
            foreach(XmlNode n in x.ChildNodes) { 
            
                if (n.Name == "Capitulo")
                {
                    List<Pasaje> Listapasajes = RecorrerPasajes(n);             
                    Capitulo cap = new Capitulo(n.Attributes[0].InnerText, int.Parse(n.Attributes[1].InnerText), Listapasajes);
                    nov.Capitulos.Add(cap);
                }
                else
                {
                    Personaje per = new Personaje(n.Attributes["Nombre"].InnerText, n.Attributes["Resumen"].InnerText);
                    nov.Personajes.Add(per);
                }
                Console.WriteLine(n.Name);
            }
        }
        /// <summary>
        /// metodo auxiliar que recorre los pasajes de los capitulos en el documento de salvaguarda para cargar sus datos 
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        private List<Pasaje> RecorrerPasajes(XmlNode n)
        {
            List<Pasaje> toret = new List<Pasaje>();
            foreach(XmlNode nc in n.ChildNodes)
            {
                foreach(XmlNode np in nc.ChildNodes) { 
                try { 
                Pasaje p = new Pasaje(np.Attributes[0].InnerText, int.Parse(np.Attributes[1].InnerText), np.Attributes[2].InnerText);
                toret.Add(p);
                }
                catch { }
            }
            }
            return toret;
        }
        /// <summary>
        /// Crea un documento Novelas.dat con la salvaguarda de todos los datos de las novelas y sus componentes creados en la aplicación
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            XmlDocument xd = new XmlDocument();
            XmlNode nodo = xd.CreateNode(XmlNodeType.XmlDeclaration, "xml", ""); 
            ((XmlDeclaration)nodo).Encoding = "utf-8";
            xd.AppendChild(nodo);
            XmlNode nodoPpal = xd.CreateNode(XmlNodeType.Element, "Novelas", "");
            xd.AppendChild(nodoPpal);
            foreach (Novela n in Novelas)
            {
                XmlNode nodoNovela = xd.CreateNode(XmlNodeType.Element, "Novela", "");
                
                XmlAttribute ntit = xd.CreateAttribute("Titulo");
                ntit.InnerText = !string.IsNullOrEmpty(n.Titulo)? n.Titulo : "  ";
                nodoNovela.Attributes.Append(ntit);
                XmlAttribute aut = xd.CreateAttribute("Autor");
                aut.InnerText = !string.IsNullOrEmpty(n.Autor) ? n.Autor : "  ";
                nodoNovela.Attributes.Append(aut);
                XmlAttribute nres = xd.CreateAttribute("Resumen");
                nres.InnerText = !string.IsNullOrEmpty(n.Resumen) ? n.Resumen : "  ";
                nodoNovela.Attributes.Append(nres);

                XmlNode nodoCaps = xd.CreateNode(XmlNodeType.Element, "Capitulos", "");
                foreach(Capitulo c in n.Capitulos)
                {
                    string num = c.NumCap.ToString();
                    XmlNode nodoCapitulo = xd.CreateNode(XmlNodeType.Element, "Capitulo", "");

                    XmlAttribute ctit = xd.CreateAttribute("Titulo");
                    ctit.InnerText = !string.IsNullOrEmpty(c.Titulo) ? c.Titulo : "  ";
                    nodoCapitulo.Attributes.Append(ctit);
                    XmlAttribute ccap = xd.CreateAttribute("Num.Capitulos");
                    ccap.InnerText = !string.IsNullOrEmpty(num) ? num : " 0 "; 
                    nodoCapitulo.Attributes.Append(ccap);
                    XmlNode nodoPas = xd.CreateNode(XmlNodeType.Element, "Pasajes", "");

                    foreach (Pasaje p in c.Pasajes)
                    {
                        string numpas = p.NumPas.ToString();
                        XmlNode nodoPasaje = xd.CreateNode(XmlNodeType.Element, "Pasaje", "");

                        XmlAttribute pRes = xd.CreateAttribute("Resumen");
                        pRes.InnerText = !string.IsNullOrEmpty(p.Resumen) ? p.Resumen : "  ";
                        nodoPasaje.Attributes.Append(pRes);
                        XmlAttribute pNum = xd.CreateAttribute("num.Pasaje");
                        pNum.InnerText = !string.IsNullOrEmpty(numpas) ? numpas : "0"; 

                        nodoPasaje.Attributes.Append(pNum);
                        XmlAttribute pText = xd.CreateAttribute("Texto");
                        pText.InnerText = !string.IsNullOrEmpty(p.TextoPas) ? p.TextoPas : "  ";

                        nodoPasaje.Attributes.Append(pText);
                        nodoPas.AppendChild(nodoPasaje);
                        
                    }
                    nodoCapitulo.AppendChild(nodoPas);
                    nodoCaps.AppendChild(nodoCapitulo);
                }
               

                nodoNovela.AppendChild(nodoCaps);
                XmlNode nodoPers = xd.CreateNode(XmlNodeType.Element, "Personajes", "");

                foreach (Personaje p in n.Personajes)
                {
                    XmlNode nodoPer = xd.CreateNode(XmlNodeType.Element, "Personaje", "");

                    XmlAttribute perNom = xd.CreateAttribute("Nombre");
                    perNom.InnerText = !string.IsNullOrEmpty(p.Nombre) ? p.Nombre : "  "; 

                    nodoPer.Attributes.Append(perNom);
                    XmlAttribute perRes = xd.CreateAttribute("Resumen");
                    perRes.InnerText = !string.IsNullOrEmpty(p.Resumen) ? p.Resumen : "  "; ;

                    nodoPer.Attributes.Append(perRes);
                    nodoPers.AppendChild(nodoPer);
                }
                nodoNovela.AppendChild(nodoPers);

                nodoPpal.AppendChild(nodoNovela);
            }
            xd.Save("Novelas.dat");

            this.Close();
        }

    }
}
