﻿
namespace Aplicacion_Novelas.Forms.Showall
{
    partial class FPasajeParticular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbResumen = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbResum = new System.Windows.Forms.TextBox();
            this.tbNum = new System.Windows.Forms.TextBox();
            this.rtbTexto = new System.Windows.Forms.RichTextBox();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbResumen
            // 
            this.lbResumen.AutoSize = true;
            this.lbResumen.Location = new System.Drawing.Point(71, 30);
            this.lbResumen.Name = "lbResumen";
            this.lbResumen.Size = new System.Drawing.Size(62, 15);
            this.lbResumen.TabIndex = 0;
            this.lbResumen.Text = "Resumen: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numero Pasaje:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Texto: ";
            // 
            // tbResum
            // 
            this.tbResum.Enabled = false;
            this.tbResum.Location = new System.Drawing.Point(167, 22);
            this.tbResum.Name = "tbResum";
            this.tbResum.Size = new System.Drawing.Size(544, 23);
            this.tbResum.TabIndex = 3;
            // 
            // tbNum
            // 
            this.tbNum.Enabled = false;
            this.tbNum.Location = new System.Drawing.Point(167, 72);
            this.tbNum.Name = "tbNum";
            this.tbNum.Size = new System.Drawing.Size(52, 23);
            this.tbNum.TabIndex = 4;
            this.tbNum.TextChanged += new System.EventHandler(this.tbNum_TextChanged);
            // 
            // rtbTexto
            // 
            this.rtbTexto.Enabled = false;
            this.rtbTexto.Location = new System.Drawing.Point(71, 147);
            this.rtbTexto.Name = "rtbTexto";
            this.rtbTexto.Size = new System.Drawing.Size(640, 249);
            this.rtbTexto.TabIndex = 5;
            this.rtbTexto.Text = "";
            // 
            // btnCerrar
            // 
            this.btnCerrar.Location = new System.Drawing.Point(333, 415);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(75, 23);
            this.btnCerrar.TabIndex = 6;
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // FPasajeParticular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 450);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.rtbTexto);
            this.Controls.Add(this.tbNum);
            this.Controls.Add(this.tbResum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbResumen);
            this.Name = "FPasajeParticular";
            this.Text = "FPasajeParticular";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbResumen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbResum;
        private System.Windows.Forms.TextBox tbNum;
        private System.Windows.Forms.RichTextBox rtbTexto;
        private System.Windows.Forms.Button btnCerrar;
    }
}