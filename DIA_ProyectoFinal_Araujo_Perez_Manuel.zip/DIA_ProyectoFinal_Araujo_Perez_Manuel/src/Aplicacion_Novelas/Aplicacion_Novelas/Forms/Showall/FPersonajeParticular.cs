﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Showall
{
    public partial class FPersonajeParticular : Form
    {
        Novela n;
        Personaje p;
        /// <summary>
        /// constructor, crea un datatable que se usará para buscar dentro de los pasajes contenidos en los capítulos de la novela 
        /// incidencias del nombre del personaje y los añade, finalmente se enlaza el datatable con el datagridview.
        /// </summary>
        /// <param name="p">personaje a mostrar</param>
        /// <param name="n">novela a la que pertenece</param>
        public FPersonajeParticular(Personaje p, Novela n)
        {
            this.p = p;
            this.n = n;
            InitializeComponent();
            tbNome.Text = p.Nombre;
            rtbRes.Text = p.Resumen;
            DataColumn Ccap = new DataColumn("Capitulo");
            

            DataColumn CPas = new DataColumn("Resumen Pasaje");

            DataTable dt = new DataTable();
            dt.Columns.Add(Ccap);
            dt.Columns.Add(CPas);
            foreach (Capitulo c in n.Capitulos)
            {
                foreach(Pasaje pas in c.Pasajes){
                    
                    if (pas.TextoPas.Contains(p.Nombre))
                    {
                        dt.Rows.Add(c.Titulo, pas.Resumen);
                    }
                }
            }
            dataGridView1.DataSource = dt;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
