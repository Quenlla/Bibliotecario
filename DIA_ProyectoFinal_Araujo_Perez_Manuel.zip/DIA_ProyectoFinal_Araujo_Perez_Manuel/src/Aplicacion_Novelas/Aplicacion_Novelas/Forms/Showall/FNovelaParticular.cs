﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Showall
{
    public partial class FNovelaParticular : Form
    {
        public Novela n;
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="n">novela que se cargará en el form</param>
        public FNovelaParticular(Novela n)
        {
            this.n = n;
            InitializeComponent();
            start();
        }
        /// <summary>
        /// carga los datos iniciales de los capitulos y los personajes en los datagrid así como los textboxes y ritchtextbox
        /// </summary>
        public void start()
        {
            
            dgvCapitulos.DataSource = null;
            dgvPersonaxes.DataSource = null;
            lblTitulo.Text = n.Titulo;
            lblAutor.Text = n.Autor;
            rtbResumen.Text = n.Resumen;
            dgvCapitulos.AutoGenerateColumns = true;
            dgvPersonaxes.AutoGenerateColumns = true;
            BindingList<Capitulo> capis = new BindingList<Capitulo>(n.Capitulos);
            BindingList<Personaje> persons = new BindingList<Personaje>(n.Personajes);

            dgvCapitulos.DataSource = capis;
            dgvPersonaxes.DataSource = persons;

            DataGridViewColumn col = new DataGridViewTextBoxColumn();
            col.HeaderText = "NºPasajes";
            col.Name = "pas";
            
            dgvCapitulos.Columns.Add(col);
            dgvCapitulos.Columns["pas"].DisplayIndex = 2;
            foreach (DataGridViewRow r in dgvCapitulos.Rows)
            {
                Capitulo cap = (Capitulo)r.DataBoundItem;
                r.Cells["pas"].Value = cap.Pasajes.Count.ToString();
            }
        }
        /// <summary>
        /// lanza el formulario para crear un nuevo capitulo dentro de la novela
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCapAdd_Click(object sender, EventArgs e)
        {
            new FNuevoCapitulo(n).ShowDialog();
            RefreshCapitulos();
            // start();
            
        }
        /// <summary>
        /// busca el capitulo seleccionado y lanza el formulario de edicion correspondiente con el capitulo como parametro, a continuacion refresca el datagridview
        /// para mostrar los cambios
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCapEd_Click(object sender, EventArgs e)
        {
            if(dgvCapitulos.SelectedRows[0].DataBoundItem != null) { 
            Capitulo cap = (Capitulo)dgvCapitulos.SelectedRows[0].DataBoundItem;
            new FEditCapitulo(cap).ShowDialog();
            RefreshCapitulos();
            }
        }
        /// <summary>
        /// refresca el datagridview de los capitulos, se llama en los metodos que modifican la lista de capitulos
        /// </summary>
        public void RefreshCapitulos()
        {
            dgvCapitulos.DataSource = typeof(List<Capitulo>);
            dgvCapitulos.DataSource = n.Capitulos;

            dgvCapitulos.Columns["pas"].DisplayIndex = 2;

            foreach (DataGridViewRow r in dgvCapitulos.Rows)
            {
                Capitulo cap = (Capitulo)r.DataBoundItem;
                r.Cells["pas"].Value = cap.Pasajes.Count.ToString();
            }

            dgvCapitulos.Update();
            dgvCapitulos.Refresh();
        }
        /// <summary>
        /// lanza el formulario correspondiente al capitulo clicado, a continuacion refresca la lista del datagridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvCapitulos_MouseClick(object sender, MouseEventArgs e)
        {
            try { 
            if (dgvCapitulos.SelectedRows[0].Cells[1] != null)
            {
                Capitulo cap = n.Capitulos.Where(c => c.NumCap.ToString() == dgvCapitulos.SelectedRows[0].Cells[2].Value.ToString()).First();
                new FCapituloParticular(cap,n).ShowDialog();
                RefreshCapitulos();
            }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void dgvCapitulos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
                return;
        }
        /// <summary>
        /// Busca el personaje seleccionado en base a los campos del datagridview de personajes y lanza el formulario de edicion de personaje con este cargado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPerEd_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPersonaxes.SelectedRows[0].DataBoundItem != null)
                {
                    Personaje pers = (Personaje) dgvPersonaxes.SelectedRows[0].DataBoundItem;
                    new FEditPersonaje(pers).ShowDialog();
                    RefreshPersonaxes();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        /// <summary>
        /// lanza el formulario de creacion de un nuevo personaje
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPerVer_Click(object sender, EventArgs e)
        {

            new FNuevoPersonaje(n).ShowDialog();
            RefreshPersonaxes();
        }
        /// <summary>
        /// recarga el datagridview de personajes para mostrar los cambios efectuados sobre la lista de personajes cuando algun metodo la modifica
        /// </summary>
        public void RefreshPersonaxes()
        {

            dgvPersonaxes.DataSource = typeof(List<Personaje>);
            dgvPersonaxes.DataSource = n.Personajes;

            dgvPersonaxes.Update();
            dgvPersonaxes.Refresh();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {

            this.Close();
        }
        /// <summary>
        /// busca entre los capitulos aquellos con un titulo que corresponda al escrito en el textbox correspondiente y refresca con ellos el datagridview de capitulos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscarCap_Click(object sender, EventArgs e)
        {
            dgvCapitulos.DataSource = typeof(List<Capitulo>);
            if (string.IsNullOrEmpty(tbBuscarCap.Text)) {
                dgvCapitulos.DataSource = n.Capitulos;
            }
            else
            {
                dgvCapitulos.DataSource = n.Capitulos.Where(t=>t.Titulo.Contains(tbBuscarCap.Text));

            }
            dgvCapitulos.Columns["pas"].DisplayIndex = 2;

            foreach (DataGridViewRow r in dgvCapitulos.Rows)
            {
                Capitulo cap = (Capitulo)r.DataBoundItem;
                r.Cells["pas"].Value = cap.Pasajes.Count.ToString();
            }

            dgvCapitulos.Update();
            dgvCapitulos.Refresh();
        }
        /// <summary>
        /// busca entre los personajes aquellos con un titulo que corresponda al escrito en el textbox correspondiente y refresca con ellos el datagridview de personajes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBuscarPer_Click(object sender, EventArgs e)
        {
            dgvPersonaxes.DataSource = typeof(List<Personaje>);
            if (string.IsNullOrEmpty(tbBuscarPer.Text))
            {
                dgvPersonaxes.DataSource = n.Personajes;
            }
            else
            {
                dgvPersonaxes.DataSource = n.Personajes.Where(n => n.Nombre.Contains(tbBuscarPer.Text));

            }


            dgvPersonaxes.Update();
            dgvPersonaxes.Refresh();
        }
        /// <summary>
        /// elimina el personaje seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPerEl_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPersonaxes.SelectedRows[0].DataBoundItem != null)
                {
                    Personaje pers = (Personaje)dgvPersonaxes.SelectedRows[0].DataBoundItem;
                    n.Personajes.Remove(pers);
                    RefreshPersonaxes();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        /// <summary>
        /// elimina el capitulo seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCapEl_Click(object sender, EventArgs e)
        {

            if (dgvCapitulos.SelectedRows[0].DataBoundItem != null)
            {
                Capitulo cap = (Capitulo)dgvCapitulos.SelectedRows[0].DataBoundItem;
                n.Capitulos.Remove(cap);
                RefreshCapitulos();
            }
        }

        private void dgvPersonaxes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        /// <summary>
        /// lanza la vista particular del personaje seleccionado y refresca el datagridview de personajes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvPersonaxes_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (dgvPersonaxes.SelectedRows[0].Cells[1] != null)
                {
                    Personaje per = n.Personajes.Where(c => c.Nombre == dgvPersonaxes.SelectedRows[0].Cells[0].Value.ToString()).First();
                    new FPersonajeParticular(per, n).ShowDialog();
                    RefreshCapitulos();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
