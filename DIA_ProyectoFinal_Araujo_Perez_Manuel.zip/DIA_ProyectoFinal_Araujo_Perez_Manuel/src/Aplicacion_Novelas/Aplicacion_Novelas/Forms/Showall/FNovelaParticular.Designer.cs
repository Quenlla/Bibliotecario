﻿
namespace Aplicacion_Novelas.Forms.Showall
{
    partial class FNovelaParticular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblAutor = new System.Windows.Forms.Label();
            this.rtbResumen = new System.Windows.Forms.RichTextBox();
            this.dgvCapitulos = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBuscarCap = new System.Windows.Forms.Button();
            this.tbBuscarCap = new System.Windows.Forms.TextBox();
            this.btnCapEl = new System.Windows.Forms.Button();
            this.btnCapVer = new System.Windows.Forms.Button();
            this.btnCapEd = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnBuscarPer = new System.Windows.Forms.Button();
            this.tbBuscarPer = new System.Windows.Forms.TextBox();
            this.btnPerEl = new System.Windows.Forms.Button();
            this.dgvPersonaxes = new System.Windows.Forms.DataGridView();
            this.btnPerVer = new System.Windows.Forms.Button();
            this.btnPerEd = new System.Windows.Forms.Button();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCapitulos)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonaxes)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Titulo : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Autor : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Resumen :";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(93, 25);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(38, 15);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "label4";
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Location = new System.Drawing.Point(93, 51);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(38, 15);
            this.lblAutor.TabIndex = 4;
            this.lblAutor.Text = "label5";
            // 
            // rtbResumen
            // 
            this.rtbResumen.Enabled = false;
            this.rtbResumen.Location = new System.Drawing.Point(19, 106);
            this.rtbResumen.Name = "rtbResumen";
            this.rtbResumen.Size = new System.Drawing.Size(700, 56);
            this.rtbResumen.TabIndex = 5;
            this.rtbResumen.Text = "";
            // 
            // dgvCapitulos
            // 
            this.dgvCapitulos.AllowUserToAddRows = false;
            this.dgvCapitulos.AllowUserToDeleteRows = false;
            this.dgvCapitulos.AllowUserToOrderColumns = true;
            this.dgvCapitulos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCapitulos.Location = new System.Drawing.Point(6, 89);
            this.dgvCapitulos.MultiSelect = false;
            this.dgvCapitulos.Name = "dgvCapitulos";
            this.dgvCapitulos.RowTemplate.Height = 25;
            this.dgvCapitulos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCapitulos.Size = new System.Drawing.Size(370, 126);
            this.dgvCapitulos.TabIndex = 6;
            this.dgvCapitulos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCapitulos_CellClick);
            this.dgvCapitulos.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgvCapitulos_MouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBuscarCap);
            this.groupBox1.Controls.Add(this.tbBuscarCap);
            this.groupBox1.Controls.Add(this.btnCapEl);
            this.groupBox1.Controls.Add(this.btnCapVer);
            this.groupBox1.Controls.Add(this.btnCapEd);
            this.groupBox1.Controls.Add(this.dgvCapitulos);
            this.groupBox1.Location = new System.Drawing.Point(13, 185);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 255);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Capítulos";
            // 
            // btnBuscarCap
            // 
            this.btnBuscarCap.Location = new System.Drawing.Point(269, 37);
            this.btnBuscarCap.Name = "btnBuscarCap";
            this.btnBuscarCap.Size = new System.Drawing.Size(88, 23);
            this.btnBuscarCap.TabIndex = 14;
            this.btnBuscarCap.Text = "Buscar";
            this.btnBuscarCap.UseVisualStyleBackColor = true;
            this.btnBuscarCap.Click += new System.EventHandler(this.btnBuscarCap_Click);
            // 
            // tbBuscarCap
            // 
            this.tbBuscarCap.Location = new System.Drawing.Point(22, 38);
            this.tbBuscarCap.Name = "tbBuscarCap";
            this.tbBuscarCap.Size = new System.Drawing.Size(241, 23);
            this.tbBuscarCap.TabIndex = 13;
            // 
            // btnCapEl
            // 
            this.btnCapEl.Location = new System.Drawing.Point(28, 224);
            this.btnCapEl.Name = "btnCapEl";
            this.btnCapEl.Size = new System.Drawing.Size(75, 23);
            this.btnCapEl.TabIndex = 12;
            this.btnCapEl.Text = "Eliminar";
            this.btnCapEl.UseVisualStyleBackColor = true;
            this.btnCapEl.Click += new System.EventHandler(this.btnCapEl_Click);
            // 
            // btnCapVer
            // 
            this.btnCapVer.Location = new System.Drawing.Point(282, 224);
            this.btnCapVer.Name = "btnCapVer";
            this.btnCapVer.Size = new System.Drawing.Size(75, 23);
            this.btnCapVer.TabIndex = 10;
            this.btnCapVer.Text = "Añadir";
            this.btnCapVer.UseVisualStyleBackColor = true;
            this.btnCapVer.Click += new System.EventHandler(this.btnCapAdd_Click);
            // 
            // btnCapEd
            // 
            this.btnCapEd.Location = new System.Drawing.Point(159, 224);
            this.btnCapEd.Name = "btnCapEd";
            this.btnCapEd.Size = new System.Drawing.Size(75, 23);
            this.btnCapEd.TabIndex = 11;
            this.btnCapEd.Text = "Editar";
            this.btnCapEd.UseVisualStyleBackColor = true;
            this.btnCapEd.Click += new System.EventHandler(this.btnCapEd_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnBuscarPer);
            this.groupBox2.Controls.Add(this.tbBuscarPer);
            this.groupBox2.Controls.Add(this.btnPerEl);
            this.groupBox2.Controls.Add(this.dgvPersonaxes);
            this.groupBox2.Controls.Add(this.btnPerVer);
            this.groupBox2.Controls.Add(this.btnPerEd);
            this.groupBox2.Location = new System.Drawing.Point(401, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(324, 255);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personajes";
            // 
            // btnBuscarPer
            // 
            this.btnBuscarPer.Location = new System.Drawing.Point(213, 37);
            this.btnBuscarPer.Name = "btnBuscarPer";
            this.btnBuscarPer.Size = new System.Drawing.Size(88, 23);
            this.btnBuscarPer.TabIndex = 16;
            this.btnBuscarPer.Text = "Buscar";
            this.btnBuscarPer.UseVisualStyleBackColor = true;
            this.btnBuscarPer.Click += new System.EventHandler(this.btnBuscarPer_Click);
            // 
            // tbBuscarPer
            // 
            this.tbBuscarPer.Location = new System.Drawing.Point(13, 39);
            this.tbBuscarPer.Name = "tbBuscarPer";
            this.tbBuscarPer.Size = new System.Drawing.Size(187, 23);
            this.tbBuscarPer.TabIndex = 15;
            // 
            // btnPerEl
            // 
            this.btnPerEl.Location = new System.Drawing.Point(226, 221);
            this.btnPerEl.Name = "btnPerEl";
            this.btnPerEl.Size = new System.Drawing.Size(75, 23);
            this.btnPerEl.TabIndex = 15;
            this.btnPerEl.Text = "Eliminar";
            this.btnPerEl.UseVisualStyleBackColor = true;
            this.btnPerEl.Click += new System.EventHandler(this.btnPerEl_Click);
            // 
            // dgvPersonaxes
            // 
            this.dgvPersonaxes.AllowUserToAddRows = false;
            this.dgvPersonaxes.AllowUserToDeleteRows = false;
            this.dgvPersonaxes.AllowUserToOrderColumns = true;
            this.dgvPersonaxes.AllowUserToResizeRows = false;
            this.dgvPersonaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPersonaxes.Location = new System.Drawing.Point(6, 89);
            this.dgvPersonaxes.MultiSelect = false;
            this.dgvPersonaxes.Name = "dgvPersonaxes";
            this.dgvPersonaxes.RowTemplate.Height = 25;
            this.dgvPersonaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPersonaxes.Size = new System.Drawing.Size(312, 126);
            this.dgvPersonaxes.TabIndex = 6;
            this.dgvPersonaxes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPersonaxes_CellClick);
            this.dgvPersonaxes.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgvPersonaxes_MouseClick);
            // 
            // btnPerVer
            // 
            this.btnPerVer.Location = new System.Drawing.Point(21, 221);
            this.btnPerVer.Name = "btnPerVer";
            this.btnPerVer.Size = new System.Drawing.Size(75, 23);
            this.btnPerVer.TabIndex = 13;
            this.btnPerVer.Text = "Añadir";
            this.btnPerVer.UseVisualStyleBackColor = true;
            this.btnPerVer.Click += new System.EventHandler(this.btnPerVer_Click);
            // 
            // btnPerEd
            // 
            this.btnPerEd.Location = new System.Drawing.Point(125, 221);
            this.btnPerEd.Name = "btnPerEd";
            this.btnPerEd.Size = new System.Drawing.Size(75, 23);
            this.btnPerEd.TabIndex = 14;
            this.btnPerEd.Text = "Editar";
            this.btnPerEd.UseVisualStyleBackColor = true;
            this.btnPerEd.Click += new System.EventHandler(this.btnPerEd_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Location = new System.Drawing.Point(547, 447);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(98, 23);
            this.btnCerrar.TabIndex = 10;
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 451);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(366, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Click en una celda para acceder a los detalles del Capitulo/Personaje";
            // 
            // FNovelaParticular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 482);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.rtbResumen);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FNovelaParticular";
            this.Text = "FNovelaParticular";
            ((System.ComponentModel.ISupportInitialize)(this.dgvCapitulos)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonaxes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.RichTextBox rtbResumen;
        private System.Windows.Forms.DataGridView dgvCapitulos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCapEl;
        private System.Windows.Forms.Button btnCapVer;
        private System.Windows.Forms.Button btnCapEd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPerEl;
        private System.Windows.Forms.DataGridView dgvPersonaxes;
        private System.Windows.Forms.Button btnPerVer;
        private System.Windows.Forms.Button btnPerEd;
        private System.Windows.Forms.Button btnBuscarCap;
        private System.Windows.Forms.TextBox tbBuscarCap;
        private System.Windows.Forms.Button btnBuscarPer;
        private System.Windows.Forms.TextBox tbBuscarPer;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Label label4;
    }
}