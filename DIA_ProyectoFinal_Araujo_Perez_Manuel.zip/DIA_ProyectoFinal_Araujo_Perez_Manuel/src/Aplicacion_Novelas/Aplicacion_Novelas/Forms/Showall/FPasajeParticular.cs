﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Showall
{
    public partial class FPasajeParticular : Form
    {
        Pasaje p;
        /// <summary>
        /// Constructor, carga los datos del pasaje en los textbox correspondientes de la interfaz
        /// </summary>
        /// <param name="p">Pasaje que se mostrará</param>
        public FPasajeParticular(Pasaje p)
        {
            this.p = p;
            InitializeComponent();
            tbNum.Text = p.NumPas.ToString();
            tbResum.Text = p.Resumen;
            rtbTexto.Text = p.TextoPas;
        }

        private void tbNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
