﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Showall
{
    public partial class FCapituloParticular : Form
    {
        Capitulo c;
        Novela n;
        List<Pasaje> pasajes;
        /// <summary>
        /// constructor de la clase
        /// </summary>
        /// <param name="c">Capitulo a cargar</param>
        /// <param name="n">Novela a la que pertenece el capitulo</param>
        public FCapituloParticular(Capitulo c,Novela n)
        {
            InitializeComponent();
            this.c = c;
            this.n = n;
            lblNovela.Text = n.Titulo;
            lblTitulo.Text = c.Titulo;
            lblNumero.Text = c.NumCap.ToString();
            this.pasajes = c.Pasajes;
           
            BindingList<Pasaje> pas = new BindingList<Pasaje>(c.Pasajes);
            dgvPasaje.DataSource = pas;
            dgvPasaje.Columns[2].Visible = false;
            dgvPasaje.Columns[0].DisplayIndex = 1;
            dgvPasaje.Columns[1].DisplayIndex = 0;

        }
        /// <summary>
        /// lanza unformulario para crear un nuevo pasaje y a continuación refresca el datagridview de pasajes para reflejar los cambios en el nuevo pasaje
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            new FNuevoPasaje(n,c).ShowDialog();
            refreshPas();
        }
        /// <summary>
        /// refresca el datagridview de pasajes para mantenerlo actualizado
        /// </summary>
    public void refreshPas()
        {
            try { 
            dgvPasaje.DataSource = typeof(List<Pasaje>);
            dgvPasaje.DataSource = c.Pasajes;
            dgvPasaje.Columns[2].Visible = false;
            dgvPasaje.Update();
            dgvPasaje.Refresh();
            }
            catch { }
            }
        /// <summary>
        /// lanza el formulario de edición del pasaje seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditar_Click(object sender, EventArgs e)
        {





            try
            {
                if (dgvPasaje.SelectedRows[0].DataBoundItem != null)
                {
                    Pasaje p = (Pasaje)dgvPasaje.SelectedRows[0].DataBoundItem;
                    new FEditPasaje(p,n,c).ShowDialog();
                    refreshPas();
                }

            }
            catch(Exception ex)
            { 
             }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {

            this.Close();
        }
        /// <summary>
        /// Elimina el pasaje seleccionado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPasaje.SelectedRows[0].DataBoundItem != null)
                {
                    Pasaje p = (Pasaje)dgvPasaje.SelectedRows[0].DataBoundItem;
                    c.Pasajes.Remove(p);
                    refreshPas();

                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}
