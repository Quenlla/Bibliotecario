﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Aplicacion_Novelas.Forms.Edit;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Showall
{
    public partial class FTreeView : Form
    {
        List<Novela> ln;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="ln">lista de las novelas en el sistema</param>
        public FTreeView(List<Novela> ln)
        {
            this.ln = ln;
            InitializeComponent();
            LoadNodos();
        }
        /// <summary>
        /// Metodo para cargar los nodos del arbol, recorre para cada novela las listas de capitulos y personajes y para los capitulos 
        /// recorre los pasajes que los conforman y va guardando sus identificadores anidadamente
        /// </summary>
        public void LoadNodos()
        {
            tvNovela.Nodes.Clear();
            TreeNode ppl = new TreeNode();
            ppl.Text = "Novelas";
            foreach (Novela n in ln)
            {
                TreeNode root = new TreeNode();
                root.Text = n.Titulo;
                TreeNode capitulos = new TreeNode();
                capitulos.Text = "Capitulos";
                foreach (Capitulo cap in n.Capitulos)
                {
                    TreeNode capi = new TreeNode();
                    capi.Text = cap.Titulo;
                    TreeNode Pasajes = new TreeNode();
                    Pasajes.Text = "Pasajes";
                    foreach (Pasaje pas in cap.Pasajes)
                    {
                        TreeNode pasa = new TreeNode();
                        pasa.Text = pas.Resumen;
                        Pasajes.Nodes.Add(pasa);
                    }
                    capi.Nodes.Add(Pasajes);
                    capitulos.Nodes.Add(capi);

                }
                root.Nodes.Add(capitulos);

                TreeNode personaje = new TreeNode();
                personaje.Text = "Personajes";
                foreach (Personaje per in n.Personajes)
                {

                    TreeNode person = new TreeNode();
                    person.Text = per.Nombre;
                    personaje.Nodes.Add(person);
                }
                root.Nodes.Add(personaje);
                ppl.Nodes.Add(root);
            }
            tvNovela.Nodes.Add(ppl);

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Busca en los nodos anteriores que tipo de objeto es para poder rellenar el richTextBox correspondiente a su resumen, en caso de tenerlo.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvNovela_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Parent != null) { 
                switch (e.Node.Parent.Text)
                {
                    case "Novelas":
                        Novela n = ln.Where(n => n.Titulo == e.Node.Text).First();
                        rtbRes.Text = n.Resumen;
                        break;
                    case "Capitulos":
                        rtbRes.Text = "";
                        break;
                    case "Pasajes":
                        Novela ncp = ln.Where(n => n.Titulo == e.Node.Parent.Parent.Parent.Parent.Text).First();
                        Capitulo cp = ncp.Capitulos.Where(c => c.Titulo == e.Node.Parent.Parent.Text).First();
                        Pasaje p = cp.Pasajes.Where(p => p.Resumen == e.Node.Text).First();
                        rtbRes.Text = p.Resumen;
                        break;
                    case "Personajes":
                        Novela npc = ln.Where(n => n.Titulo == e.Node.Parent.Parent.Text).First();
                        Personaje per = npc.Personajes.Where(p => p.Nombre == e.Node.Text).First();
                        rtbRes.Text = per.Resumen;
                        break;
                }
            }
            else
            {
                rtbRes.Text = "";
            }
            this.Update();
        }
        /// <summary>
        /// Busca en los nodos superiores el tipo de objeto que es el nodo seleccionado y lanza el form correspondiente para su edición.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvNovela_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Parent != null) { 
                switch (e.Node.Parent.Text)
                {
                    case "Novelas":
                        Novela n = ln.Where(n => n.Titulo == e.Node.Text).First();
                        new FEditNovela(n).ShowDialog();
                        
                        break;

                    case "Capitulos":
                        Novela nc = ln.Where(n => n.Titulo == e.Node.Parent.Parent.Text).First();
                        Capitulo c = nc.Capitulos.Where(c => c.Titulo == e.Node.Text).First();
                        new FEditCapitulo(c).ShowDialog();
                        break;
                    case "Pasajes":
                        Novela ncp = ln.Where(n => n.Titulo == e.Node.Parent.Parent.Parent.Parent.Text).First();
                        Capitulo cp = ncp.Capitulos.Where(c => c.Titulo == e.Node.Parent.Parent.Text).First();
                        Pasaje p = cp.Pasajes.Where(p => p.Resumen == e.Node.Text).First();
                        new FEditPasaje(p, ncp, cp).ShowDialog();
                        break;
                    case "Personajes":
                        Novela npc = ln.Where(n => n.Titulo == e.Node.Parent.Parent.Text).First();
                        Personaje per = npc.Personajes.Where(p => p.Nombre == e.Node.Text).First();
                        new FEditPersonaje(per).ShowDialog();
                        break;

                }
            LoadNodos();
            }
        }
    }
}
