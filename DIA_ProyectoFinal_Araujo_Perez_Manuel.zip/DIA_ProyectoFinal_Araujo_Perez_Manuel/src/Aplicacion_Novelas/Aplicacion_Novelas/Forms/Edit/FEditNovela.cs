﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms.Edit
{
    public partial class FEditNovela : Form
    {
        Novela n;
        /// <summary>
        /// Constructor de la clase, carga los datos de la novelaa editar n los textbox correspondientes
        /// </summary>
        /// <param name="n"></param>
        public FEditNovela(Novela n)
        {
            this.n = n;
            InitializeComponent();
            tbAutor.Text = n.Autor;
            tbTitulo.Text = n.Titulo;
            rtbResumen.Text = n.Resumen;
        }
        
        private void btnCancelar_Click(object sender, EventArgs e)
        {

            this.Close();
        }
        /// <summary>
        /// Guarda los cambios realizados en los textbox en los atributos correspondientes de la clase novela
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            n.Resumen = rtbResumen.Text;
            n.Titulo = tbTitulo.Text;
            n.Autor = tbAutor.Text;
            this.Close();
        }
    }
}
