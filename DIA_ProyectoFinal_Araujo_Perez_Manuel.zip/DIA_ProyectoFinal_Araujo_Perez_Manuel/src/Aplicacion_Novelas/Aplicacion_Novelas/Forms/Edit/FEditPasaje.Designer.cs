﻿
namespace Aplicacion_Novelas.Forms
{
    partial class FEditPasaje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rtbPasRes = new System.Windows.Forms.RichTextBox();
            this.rtbTexto = new System.Windows.Forms.RichTextBox();
            this.tbNum = new System.Windows.Forms.TextBox();
            this.tbCapNom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNomNov = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre del Capítulo : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Resumen del Pasaje : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Número de Pasaje : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 298);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Texto del Pasaje : ";
            // 
            // rtbPasRes
            // 
            this.rtbPasRes.Location = new System.Drawing.Point(41, 116);
            this.rtbPasRes.Name = "rtbPasRes";
            this.rtbPasRes.Size = new System.Drawing.Size(646, 104);
            this.rtbPasRes.TabIndex = 4;
            this.rtbPasRes.Text = "";
            // 
            // rtbTexto
            // 
            this.rtbTexto.Location = new System.Drawing.Point(41, 326);
            this.rtbTexto.Name = "rtbTexto";
            this.rtbTexto.Size = new System.Drawing.Size(646, 212);
            this.rtbTexto.TabIndex = 5;
            this.rtbTexto.Text = "";
            // 
            // tbNum
            // 
            this.tbNum.Location = new System.Drawing.Point(159, 258);
            this.tbNum.Name = "tbNum";
            this.tbNum.Size = new System.Drawing.Size(100, 23);
            this.tbNum.TabIndex = 6;
            // 
            // tbCapNom
            // 
            this.tbCapNom.Enabled = false;
            this.tbCapNom.Location = new System.Drawing.Point(69, 41);
            this.tbCapNom.Name = "tbCapNom";
            this.tbCapNom.Size = new System.Drawing.Size(280, 23);
            this.tbCapNom.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nombre de la Novela : ";
            // 
            // tbNomNov
            // 
            this.tbNomNov.Enabled = false;
            this.tbNomNov.Location = new System.Drawing.Point(407, 41);
            this.tbNomNov.Name = "tbNomNov";
            this.tbNomNov.Size = new System.Drawing.Size(280, 23);
            this.tbNomNov.TabIndex = 9;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(112, 563);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(121, 38);
            this.btnCancelar.TabIndex = 10;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(500, 563);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(121, 38);
            this.btnGuardar.TabIndex = 11;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // FEditPasaje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 641);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.tbNomNov);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbCapNom);
            this.Controls.Add(this.tbNum);
            this.Controls.Add(this.rtbTexto);
            this.Controls.Add(this.rtbPasRes);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FEditPasaje";
            this.Text = "Edit Pasaje";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtbPasRes;
        private System.Windows.Forms.RichTextBox rtbTexto;
        private System.Windows.Forms.TextBox tbNum;
        private System.Windows.Forms.TextBox tbCapNom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNomNov;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
    }
}