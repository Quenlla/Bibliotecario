﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms
{
    public partial class FEditPasaje : Form
    {
        Pasaje p;
        /// <summary>
        /// Constructor del formulario de edicion de un pasaje, carga los datos del pasaje en los textbox correspondientes
        /// </summary>
        /// <param name="p">Pasaje a editar</param>
        /// <param name="n">Novela a la que pertenece el pasaje</param>
        /// <param name="c">Capitulo al que pertenece el pasaje</param>
        public FEditPasaje(Pasaje p,Novela n, Capitulo c)
        {
            this.p = p;
            InitializeComponent();
            tbCapNom.Text = c.Titulo;
            tbNomNov.Text = n.Titulo;
            tbNum.Text = p.NumPas.ToString();
            rtbTexto.Text = p.TextoPas;
            rtbPasRes.Text = p.Resumen;
        }
        /// <summary>
        /// Guarda los datos escritos en los textbox en los atributos del pasaje
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            p.TextoPas = rtbTexto.Text;
            p.Resumen = rtbPasRes.Text;
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
