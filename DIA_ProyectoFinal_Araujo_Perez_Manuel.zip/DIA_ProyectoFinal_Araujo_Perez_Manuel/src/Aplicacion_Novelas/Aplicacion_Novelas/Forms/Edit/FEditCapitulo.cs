﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas
{
    public partial class FEditCapitulo : Form
    {
        Capitulo cap;
        /// <summary>
        /// Constructor del formulario de edicion de capitulo, carga los textbox con los datos del capitulo
        /// </summary>
        /// <param name="cap">capitulo a editar</param>
        public FEditCapitulo(Capitulo cap)
        {

            this.cap = cap;
            InitializeComponent();
            tbNumCap.Text = cap.NumCap.ToString();
            tbTitulo.Text = cap.Titulo;
        }
        /// <summary>
        /// Guarda los datos escritos en los textbox en los atributos correspondientes del capitulo a editar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditar_Click(object sender, EventArgs e)
        {
            cap.Titulo = tbTitulo.Text;
            cap.NumCap = int.Parse(tbNumCap.Text);
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
