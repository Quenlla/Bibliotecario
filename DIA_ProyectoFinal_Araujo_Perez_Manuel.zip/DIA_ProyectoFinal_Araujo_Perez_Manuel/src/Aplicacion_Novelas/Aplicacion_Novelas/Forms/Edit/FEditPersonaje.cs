﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas
{
    public partial class FEditPersonaje : Form
    {
        Personaje pers;
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="pers">Personaje a editar</param>
        public FEditPersonaje(Personaje pers)
        {
            this.pers = pers;
            InitializeComponent();
            tbNom.Text = pers.Nombre;
            rtbRes.Text = pers.Resumen;
        }
        /// <summary>
        /// Guarda los cambios en los textbox en los atributos correspondientes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            pers.Nombre = tbNom.Text;
            pers.Resumen = rtbRes.Text;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
