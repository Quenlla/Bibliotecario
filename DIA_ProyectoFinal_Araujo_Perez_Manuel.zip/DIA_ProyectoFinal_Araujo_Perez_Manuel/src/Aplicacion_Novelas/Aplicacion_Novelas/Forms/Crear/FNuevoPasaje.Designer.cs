﻿
namespace Aplicacion_Novelas.Forms
{
    partial class FNuevoPasaje

    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rtbResumo = new System.Windows.Forms.RichTextBox();
            this.rtbTexto = new System.Windows.Forms.RichTextBox();
            this.tbNumPas = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.lbNomNovela = new System.Windows.Forms.Label();
            this.lbNomeCap = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre del Capítulo : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 261);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Número de Pasaje : ";
            // 
            // rtbResumo
            // 
            this.rtbResumo.AccessibleName = "rtbResumo";
            this.rtbResumo.Location = new System.Drawing.Point(11, 22);
            this.rtbResumo.Name = "rtbResumo";
            this.rtbResumo.Size = new System.Drawing.Size(646, 104);
            this.rtbResumo.TabIndex = 4;
            this.rtbResumo.Text = "";
            // 
            // rtbTexto
            // 
            this.rtbTexto.AccessibleName = "rtbTexto";
            this.rtbTexto.Location = new System.Drawing.Point(41, 326);
            this.rtbTexto.Name = "rtbTexto";
            this.rtbTexto.Size = new System.Drawing.Size(646, 225);
            this.rtbTexto.TabIndex = 5;
            this.rtbTexto.Text = "";
            // 
            // tbNumPas
            // 
            this.tbNumPas.Enabled = false;
            this.tbNumPas.Location = new System.Drawing.Point(159, 258);
            this.tbNumPas.Name = "tbNumPas";
            this.tbNumPas.Size = new System.Drawing.Size(100, 23);
            this.tbNumPas.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nombre de la Novela : ";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(112, 563);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(121, 38);
            this.btnCancelar.TabIndex = 10;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(500, 563);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(121, 38);
            this.btnGuardar.TabIndex = 11;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // lbNomNovela
            // 
            this.lbNomNovela.AutoSize = true;
            this.lbNomNovela.Location = new System.Drawing.Point(395, 49);
            this.lbNomNovela.Name = "lbNomNovela";
            this.lbNomNovela.Size = new System.Drawing.Size(128, 15);
            this.lbNomNovela.TabIndex = 12;
            this.lbNomNovela.Text = "Nombre de la Novela : ";
            // 
            // lbNomeCap
            // 
            this.lbNomeCap.AutoSize = true;
            this.lbNomeCap.Location = new System.Drawing.Point(60, 49);
            this.lbNomeCap.Name = "lbNomeCap";
            this.lbNomeCap.Size = new System.Drawing.Size(127, 15);
            this.lbNomeCap.TabIndex = 13;
            this.lbNomeCap.Text = "Nombre del Capítulo : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbResumo);
            this.groupBox1.Location = new System.Drawing.Point(30, 95);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(668, 143);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Resumen : ";
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(30, 300);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(667, 257);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Texto : ";
            // 
            // FNuevoPasaje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 618);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbNomeCap);
            this.Controls.Add(this.lbNomNovela);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbNumPas);
            this.Controls.Add(this.rtbTexto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Name = "FNuevoPasaje";
            this.Text = "FNuevoPasaje";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rtbResumo;
        private System.Windows.Forms.RichTextBox rtbTexto;
        private System.Windows.Forms.TextBox tbNumPas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Label lbNomNovela;
        private System.Windows.Forms.Label lbNomeCap;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}