﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Aplicacion_Novelas.Forms.Showall;

namespace Aplicacion_Novelas
{
    public partial class FNuevaNovela : Form
    {
        public List<Novela> Novelas = new List<Novela>();
        /// <summary>
        /// Constructor del formulario para crear una nueva novela
        /// </summary>
        /// <param name="Novelas">Lista de novelas del sistema</param>
        public FNuevaNovela(List<Novela> Novelas)
        {
            this.Novelas = Novelas;
            InitializeComponent();
        }

        private void FNuevaNovela_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Crea una nueva novela con los parametros introducidos en los textbox y la añade a la lista de novelas del sistema
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCrear_Click(object sender, EventArgs e)
        {
            Novela n = new Novela(tbTitulo.Text, tbAutor.Text, tbResumen.Text);
            Novelas.Add(n);
            new FNovelaParticular(n).ShowDialog();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
