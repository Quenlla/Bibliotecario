﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas.Forms
{
    public partial class FNuevoPasaje : Form
    {
        Capitulo c;
        Novela n;
        Pasaje p;
        /// <summary>
        /// Constructor de la clase para crear un nuevo pasaje, carga en los textbox los datos del capitulo y la novela a la que pertenece
        /// </summary>
        /// <param name="n">Novela a la que pertenece el pasaje</param>
        /// <param name="c">Capitulo al que pertenece el pasaje</param>
        public FNuevoPasaje(Novela n,Capitulo c)
        {
            this.n = n;
            this.c = c;
            InitializeComponent();
            lbNomeCap.Text = c.Titulo;
            lbNomNovela.Text = n.Titulo;
            tbNumPas.Text = (c.Pasajes.Count + 1).ToString();
        }
        /// <summary>
        /// Crea un nuevo pasaje dentro del capitulo con los parametros correspondientes a los textbox del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int numPas = c.Pasajes.Count + 1;
            c.Pasajes.Add(new Pasaje(rtbResumo.Text, numPas, rtbTexto.Text));
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
