﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas
{
    public partial class FNuevoCapitulo : Form
    {
        Novela n;
        /// <summary>
        /// Constructor del formulario para crear un nuevo capitulo, cuenta los capitulos de la novela y rellena el textbox que nos indica en numero de capitulo
        /// </summary>
        /// <param name="n"></param>
        public FNuevoCapitulo(Novela n)
        {
            this.n = n;
            InitializeComponent();
            if (n.Capitulos.Count.ToString() != null) 
            { 
            tbCapitulo.Text =(n.Capitulos.Count+1).ToString();
            }
            else
            {
                tbCapitulo.Text = "0";
            }
        }
        /// <summary>
        /// Crea un nuevo capitulo conlos datos introducidos en los textbox y lo añade a la novela
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Capitulo cap = new Capitulo(tbTitulo.Text, int.Parse(tbCapitulo.Text),new List<Pasaje>());
            n.Capitulos.Add(cap);
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

            this.Close();
        }
    }
}

