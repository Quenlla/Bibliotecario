﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aplicacion_Novelas
{
    public partial class FNuevoPersonaje : Form
    {
        Novela n;
        /// <summary>
        /// Constructor de la clase, carga los datos de la novela a la que pertenece el personaje en los textbox correspondientes
        /// </summary>
        /// <param name="n">Novela a la que pertenece el personaje</param>
        public FNuevoPersonaje(Novela n)
        {
            this.n = n;
            InitializeComponent();
            tbNovela.Text = n.Titulo;
            tbAutor.Text = n.Autor;
        }
        /// <summary>
        /// Crea un nuevo personaje con los datos escritos en los textbox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            n.Personajes.Add(new Personaje(tbNombre.Text, rtbResumo.Text));
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
