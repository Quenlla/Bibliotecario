﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion_Novelas
{
  public  class Personaje
    {
        public string Nombre { get; set; }
        public string Resumen { get; set; }

        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="nombre">Nombre del personaje</param>
        /// <param name="resumen">Resumen del Personaje</param>
        public Personaje(string nombre, string resumen)
        {
            this.Nombre = nombre;
            this.Resumen = resumen;
        }
    }
}
