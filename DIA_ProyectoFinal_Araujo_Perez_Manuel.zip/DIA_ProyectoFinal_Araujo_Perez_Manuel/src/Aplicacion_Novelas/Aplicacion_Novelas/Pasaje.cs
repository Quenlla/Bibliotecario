﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion_Novelas
{
   public class Pasaje
    {
        public string Resumen { get; set; }
        public int NumPas { get; set; }
        public string TextoPas { get; set; }
        /// <summary>
        /// Constructor de la clase
        /// </summary>
        /// <param name="Resumen">Resumen del Pasaje</param>
        /// <param name="NumPas">Numero del Pasaje</param>
        /// <param name="TextoPas">Texto del pasaje</param>
        public Pasaje(string Resumen, int NumPas, string TextoPas)
        {
            this.Resumen = Resumen;
            this.NumPas = NumPas;
            this.TextoPas = TextoPas;

        }
    }
}
