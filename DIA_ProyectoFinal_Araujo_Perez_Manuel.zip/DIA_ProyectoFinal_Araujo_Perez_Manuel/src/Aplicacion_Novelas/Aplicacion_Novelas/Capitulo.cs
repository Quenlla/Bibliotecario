﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion_Novelas
{
  public  class Capitulo
    {
        public string Titulo { get; set; }
        public int NumCap { get; set; }
        public List<Pasaje> Pasajes { get; set; }
            /// <summary>
            /// Constructor de la clase
            /// </summary>
            /// <param name="Titulo">Titulo del Capitulo</param>
            /// <param name="NumCap">Numero del Capitulo</param>
            /// <param name="Pasajes">Lista de pasajes que conforman el capitulo</param>
        public Capitulo(string Titulo, int NumCap, List<Pasaje> Pasajes)
        {
            this.Titulo = Titulo;
            this.NumCap = NumCap;
            this.Pasajes = Pasajes;
        }
    }
}
